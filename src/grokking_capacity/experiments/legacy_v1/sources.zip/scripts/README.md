# Experiment and analysis commands

Install with `pip install -e .`. The current paper analysis is
`gc-paper-analysis`; manuscript formatting and compilation stay beside the TeX.

Other workflows are grouped in the package and exposed through one command:

```bash
gc-workflow --list
gc-workflow discrete
gc-workflow capacity analyse_matched_capacity --figures
gc-workflow discrete run_discrete_replication --help
gc-workflow discrete report_p97_capacity_scaling
```

Use `python -m grokking_capacity.workflows` before reinstalling entry points.
The command forwards arguments unchanged and runs from the repository root.
Listing commands does not run them. Some historical controllers do not accept
`--help`; consult the listed implementation before starting training.

| Group | Implementation | Purpose |
| --- | --- | --- |
| `capacity` | `experiments/capacity_workflow/` | Matched capacity calibration and hardware comparisons |
| `cone` | `experiments/cone_workflow/` | Cone experiments, aggregation, and verification |
| `discrete` | `experiments/discrete_workflow/` | Discrete experiments, reports, and audits |
| `mechanisms` | `analysis/mechanisms/` | Mechanism experiments and analyses |
| `sensitivity` | `analysis/law_sensitivity/` | Timescale fits and estimator sensitivity |

Paths in this table are relative to `src/grokking_capacity/`. The command
catalogue is `src/grokking_capacity/workflow_catalog.json`.

## The ten retained files

- `replicate.sh <env> [suite ...]`: launch all paper suites or a selected subset.
- `run_suite.sh <suite> <env>`: launch one suite in its own tmux session.
- `run_p97_dropout_match.py`
- `run_p97_multilevel_stage.py`
- `run_p97_categorical_groks.py`
- `run_p97_capacity_scaling.py`
- `run_p97_dataset_scaling.py`
- `report_p97_dataset_scaling.py`
- `__init__.py`: package marker for the retained registered commands.
- This README.

The six p97 files retain their exact paths and contents because completed
experiment manifests record both. They are also available through
`gc-workflow discrete <filename-without-extension>`. Moving or rewriting them
would require migrating those registrations. The rest of the active workflow
code lives in the package; obsolete migration, preview, publication-patching,
and one-off shell tools have been removed. Historical versions remain in Git.

Exact archived discrete controllers are stored under
`src/grokking_capacity/experiments/discrete_workflow/frozen/`. They remain valid
for source-hash checks. To replay one with its historical helper imports, use:

```bash
gc-workflow discrete confirm_frozen confirm_discrete_20261122 --help
```

Discrete development recipes remain in `configs/discrete/`; the six registered
campaign configurations retain their original top-level paths. Training
implementations, completed results, and registered source hashes are preserved.
